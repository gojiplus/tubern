This directory stores API response fixtures for httptest.
Auto-generated via capture_requests(). Do not edit by hand.
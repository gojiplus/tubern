library(testthat)
library(tubern)

test_check("tubern")
